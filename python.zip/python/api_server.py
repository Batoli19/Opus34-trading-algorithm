"""
Dashboard API Server — Enhanced with AI Memory Data (RUNNABLE)
──────────────────────────────────────────────────────────────
Now includes:
  • Setup performance from AI memory
  • Trade reasoning and lessons
  • Real-time confidence scores
  • SSE streaming (/api/stream)
  • Serves your dashboard.html at /
"""

import json
import time
import logging
from pathlib import Path
from threading import Thread

from flask import Flask, Response, jsonify, send_from_directory, stream_with_context
from flask_cors import CORS

logger = logging.getLogger("API")


class DashboardAPI:
    def __init__(self, engine, host="0.0.0.0", port=5000):
        self.engine = engine
        self.host = host
        self.port = port
        self.app = Flask(__name__)
        CORS(self.app)
        self._setup_routes()

    def _setup_routes(self):
        web_dir = Path(__file__).parent / "web"

        # ✅ Serve your existing file: web/dashboard.html
        @self.app.route("/", methods=["GET"])
        def home():
            return send_from_directory(web_dir, "dashboard.html")

        @self.app.route("/web/<path:path>", methods=["GET"])
        def web_static(path):
            return send_from_directory(web_dir, path)

        @self.app.route("/api/status", methods=["GET"])
        def get_status():
            try:
                status = self.engine.get_status()
                return jsonify(status)
            except Exception as e:
                logger.error(f"Status error: {e}", exc_info=True)
                return jsonify({"error": str(e)}), 500

        @self.app.route("/api/stream", methods=["GET"])
        def stream():
            @stream_with_context
            def generate():
                while True:
                    try:
                        data = self.engine.get_status()
                        yield f"data: {json.dumps(data)}\n\n"
                        yield ": ping\n\n"
                        time.sleep(1)
                    except GeneratorExit:
                        logger.info("SSE client disconnected")
                        return
                    except Exception as e:
                        logger.error(f"Stream error: {e}", exc_info=True)
                        yield f"data: {json.dumps({'error': str(e)})}\n\n"
                        time.sleep(2)

            return Response(
                generate(),
                mimetype="text/event-stream",
                headers={
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",
                },
            )

        @self.app.route("/api/shutdown", methods=["POST"])
        def shutdown():
            logger.warning("Shutdown requested via API")
            # engine may not exist in standalone mode; guard it
            try:
                self.engine.shutdown.set()
                return jsonify({"status": "shutdown_requested"})
            except Exception:
                return jsonify({"status": "no_engine_attached"}), 200

    def run_async(self):
        def run():
            logger.info(f"🌐  Dashboard API starting on http://{self.host}:{self.port}")
            self.app.run(host=self.host, port=self.port, debug=False, use_reloader=False)
        thread = Thread(target=run, daemon=True)
        thread.start()
        logger.info("✅  API server started")

    def run_blocking(self):
        logger.info(f"🌐  Dashboard API starting on http://{self.host}:{self.port}")
        self.app.run(host=self.host, port=self.port, debug=False, use_reloader=False)


# ✅ THIS is why it was “silent”: you didn’t have an entrypoint.
# This allows running api_server.py directly for UI testing.
if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)-8s [%(name)s]  %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Standalone mode: no engine wired (still serves dashboard + endpoints return error)
    class _DummyEngine:
        def __init__(self):
            class _Shutdown:
                def set(self): pass
            self.shutdown = _Shutdown()

        def get_status(self):
            return {
                "connected": False,
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "account": {"balance": 0, "equity": 0, "profit": 0, "currency": "USD", "leverage": 0, "free_margin": 0},
                "stats": {"daily_pnl": 0, "daily_trades": 0, "trades": 0, "winrate": 0, "total_pnl": 0, "avg_win": 0, "avg_loss": 0, "expectancy": 0},
                "positions": [],
                "trade_log": [],
                "upcoming_news": [],
                "setup_performance": [],
                "pair_biases": {}
            }

    api = DashboardAPI(engine=_DummyEngine(), host="127.0.0.1", port=5000)
    api.run_blocking()
